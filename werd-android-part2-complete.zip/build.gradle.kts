// AGP 9.x يستخدم دعم Kotlin المدمج (built-in) — بدون الحاجة لبلجن kotlin-android منفصل
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose.compiler) apply false
}
