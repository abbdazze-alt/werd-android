package com.werd.adhkar.data.model

/**
 * تصنيفات الأذكار — النطاق الحالي (V1) أربعة فقط.
 */
enum class DhikrCategory(val displayName: String) {
    MORNING("أذكار الصباح"),
    EVENING("أذكار المساء"),
    AFTER_PRAYER("أذكار بعد الصلاة"),
    SLEEP("أذكار النوم")
}

/**
 * درجة الحديث — لا يُدرج أي ذكر في التطبيق بدون توثيق درجته.
 */
enum class HadithGrade(val displayName: String) {
    SAHIH("صحيح"),
    HASAN("حسن")
}

/**
 * الذكر الواحد بكل بياناته وتوثيقه.
 *
 * كثير من أذكار الصباح والمساء متطابقة نصًا، فبدل تكرارها كسجلّين منفصلين،
 * الذكر الواحد ينتمي لأكثر من تصنيف عبر [categories].
 */
data class Dhikr(
    val id: String,
    val categories: List<DhikrCategory>,
    val repeatCount: Int,
    val title: String,
    val text: String,
    val virtue: String,
    val source: String,
    val grade: HadithGrade,
    val narrator: String,
    val reference: String,
    val url: String? = null
)
