package com.werd.adhkar

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.werd.adhkar.ui.screens.home.HomeScreen
import com.werd.adhkar.ui.theme.WerdTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashLogger()
        enableEdgeToEdge()

        // شاشة تشخيص مؤقتة: لو صار انهيار آخر مرة، نعرض رسالته هنا بدل ما يفتح
        // التطبيق عادي — يفيدنا نشخّص المشكلة من غير Android Studio أو adb.
        val prefs = getSharedPreferences("debug", Context.MODE_PRIVATE)
        val lastCrash = prefs.getString("last_crash", null)
        if (lastCrash != null) prefs.edit().remove("last_crash").apply()

        setContent {
            WerdTheme {
                if (lastCrash != null) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        Text(
                            text = "آخر خطأ سبب توقف التطبيق:\n\n$lastCrash",
                            color = Color.Red,
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp)
                        )
                    }
                } else {
                    HomeScreen()
                }
            }
        }
    }

    /** يحفظ أي انهيار في SharedPreferences عشان نقدر نعرضه بالتشغيلة الجاية. */
    private fun installCrashLogger() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            getSharedPreferences("debug", Context.MODE_PRIVATE)
                .edit()
                .putString("last_crash", throwable.stackTraceToString())
                .commit() // مزامن (مو apply) — نضمن الكتابة تخلص قبل ما تموت العملية
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }
}
