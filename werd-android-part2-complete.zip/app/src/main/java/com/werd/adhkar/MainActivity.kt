package com.werd.adhkar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.werd.adhkar.ui.screens.home.HomeScreen
import com.werd.adhkar.ui.theme.WerdTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WerdTheme {
                HomeScreen()
            }
        }
    }
}
