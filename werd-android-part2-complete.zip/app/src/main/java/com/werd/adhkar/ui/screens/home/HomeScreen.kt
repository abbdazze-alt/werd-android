package com.werd.adhkar.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.werd.adhkar.ui.theme.WerdBrown
import com.werd.adhkar.ui.theme.WerdCream
import com.werd.adhkar.ui.theme.WerdInk
import com.werd.adhkar.ui.theme.WerdTheme

/**
 * الشاشة الرئيسية — حاليًا نسخة تجريبية تثبت شغل الزجاج السائل.
 * راح تتحول لعرض التصنيفات الأربعة الحقيقية (التنقل) في Part 3.
 */
@Composable
fun HomeScreen() {
    val backdrop = rememberLayerBackdrop()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(WerdBrown, WerdCream)))
            .layerBackdrop(backdrop)
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .size(240.dp, 120.dp)
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { RoundedCornerShape(20.dp) },
                    effects = { blur(16.dp.toPx()) }
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "وِرد — زجاج سائل ✨", color = WerdInk)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    WerdTheme {
        HomeScreen()
    }
}
