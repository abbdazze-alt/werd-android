package com.werd.adhkar.ui.navigation

// شجرة التنقل بين الشاشات (الرئيسية ← التفاصيل) — تُضاف في Part 3
