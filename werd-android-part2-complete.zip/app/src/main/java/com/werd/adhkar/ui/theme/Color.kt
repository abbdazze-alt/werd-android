package com.werd.adhkar.ui.theme

import androidx.compose.ui.graphics.Color

// نفس الهوية اللونية لنسخة الويب (وِرد PWA)
val WerdCream = Color(0xFFF3EDE3)          // الخلفية
val WerdCreamSurface = Color(0xFFFFFAF2)   // سطح البطاقات
val WerdBrown = Color(0xFF6B5745)          // اللون الأساسي (الهوية)
val WerdBrownDark = Color(0xFF4A3B2F)      // تباين داكن
val WerdInk = Color(0xFF2E2620)            // لون النص الأساسي
