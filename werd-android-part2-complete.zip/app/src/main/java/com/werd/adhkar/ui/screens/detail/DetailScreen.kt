package com.werd.adhkar.ui.screens.detail

// شاشة تفاصيل الذكر (نص كامل + عداد + مفضلة) — تُضاف في Part 5
