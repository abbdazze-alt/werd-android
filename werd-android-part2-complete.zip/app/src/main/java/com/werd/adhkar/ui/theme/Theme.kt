package com.werd.adhkar.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val WerdColorScheme = lightColorScheme(
    primary = WerdBrown,
    onPrimary = WerdCream,
    background = WerdCream,
    surface = WerdCreamSurface,
    onBackground = WerdInk,
    onSurface = WerdInk
)

@Composable
fun WerdTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = WerdColorScheme,
        typography = WerdTypography,
        content = content
    )
}
